let usernames = [
  'hacker',
  'guest',
  'player',
  'unnamed',
  'fast',
  'pro',
  'elite',
  'sniper',
  'pilot',
  'trucker',
  'tank',
  'rambo',
  'anna', // vanligaste namnen på kvinnor
  'eva',
  'maria',
  'karin',
  'kristina',
  'sara',
  'lena',
  'emma',
  'kerstin',
  'ingrid',
  'lars', // vanligaste namnen på män
  'mikael',
  'anders',
  'johan',
  'erik',
  'per',
  'karl',
  'peter',
  'thomas',
  'jan'
]

let games = [
  'Hey Robot!',
  'Super Woman New York',
  'The Scary Horror Game',
  'Dart After Dark',
  'Red Blood Cell Hell',
  'The Chess Game',
  'At The Pub - Biliards'
]

let messages = [
  'jag vill köpa %GAME%',
  '%GAME% är bäst!!!',
  'är %GAME% värt ett köp?',
  'spelet %GAME% var ingenting för mig',
  'jag känner en som köpt %GAME%',
  '%GAME%',
  '&lt;3 %GAME% &lt;3',
  '%GAME% är på väg till min brevlåda',
  'alla måste bara älska %GAME%',
  '%GAME% är helt klart bättre än %GAME2%',
  'hur bra dator behöver man för att spela %GAME%?',
  'hallå',
  'hääääääj',
  'hej då',
  'hej',
  'tja!',
  'god natt',
  'test',
  'det regnar, dags att spela',
  'jag är hungrig',
  'jag är törstig',
  'jag har tråkigt',
  'vet nån ett racingspel där man kan köra volvo?',
  'first',
  'nån som vet bra musik?',
  ':)',
  ':D',
  ':\'(',
  'XD',
  'wohoo!'
]

function random(list) {
  return list[Math.floor(Math.random() * list.length)]
}

function getUsername() {
  return random(usernames) + Math.floor(Math.random() * usernames.length)
}

function getGame() {
  return random(games)
}

function getMessage() {
  let message = random(messages)
  message = message.replace('%GAME%', getGame().toLowerCase())
  message = message.replace('%GAME2%', getGame().toLowerCase())
  return message
}

function chat(startChain = true) {
  let element = document.createElement('p')
  let username = document.createElement('span')
  let message = document.createElement('span')

  username.style.fontWeight = 'bold'
  username.innerHTML = getUsername() + ' - '
  message.innerHTML = getMessage()

  element.appendChild(username)
  element.appendChild(message)
  document.getElementById('messagesChat').prepend(element)

  if (startChain)
    setTimeout(chat, Math.random() * 5000)
}

for (let i = 0; i < 100; i++)
{
  chat(false)
}

chat()